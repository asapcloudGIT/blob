[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string] $AutomationAccountName,

    [Parameter(Mandatory = $false)]
    [string] $DestinationPath = "C:\temp\MMASetup-AMD64.exe",

    [Parameter(Mandatory = $true)]
    [string] $HybridWorkerGroupName,

    [Parameter(Mandatory = $true)]
    [string] $ResourceGroupName,

    [Parameter(Mandatory = $true)]
    [string] $WorkspaceName
)
# Login to Azure account

# Check that the automation account is valid
$AutomationAccount = Get-AzAutomationAccount -ResourceGroupName $ResourceGroupName -Name $AutomationAccountName

# Find the automation account region
$AALocation = $AutomationAccount.Location

# Print out Azure Automation Account name and region
Write-Output("Accessing Azure Automation Account named $AutomationAccountName in region $AALocation...")

# Get Azure Automation Primary Key and Endpoint
$AutomationInfo = Get-AzAutomationRegistrationInfo -ResourceGroupName $ResourceGroupName -AutomationAccountName $AutomationAccountName
$AutomationPrimaryKey = $AutomationInfo.PrimaryKey
$AutomationEndpoint = $AutomationInfo.Endpoint

# Create a new OMS workspace if needed
$WorkspaceName = New-AzOperationalInsightsWorkspace -Location $AALocation -Name $WorkspaceName -Sku Standard -ResourceGroupName $ResourceGroupName
$WorkspaceId = get-azoperationalInsightsWorkspace -ResourceGroupName $ResourceGroupName -Name $WorkspaceName -Verbose
# Get the primary key for the OMS workspace
$WorkspaceSharedKeys = Get-AzOperationalInsightsWorkspaceSharedKeys -ResourceGroupName $ResourceGroupName -Name $WorkspaceName
$WorkspaceKey = $WorkspaceSharedKeys.PrimarySharedKey

# Activate the Azure Automation solution in the workspace
Set-AzOperationalInsightsIntelligencePack -ResourceGroupName $ResourceGroupname `
    -WorkspaceName $WorkspaceName `
    -IntelligencePackName "AzureAutomation" `
    -Enabled $true
$SolutionEnabled = (get-azoperationalinsightsintelligencepack -ResourceGroupName $ResourceGroupName -WorkspaceName $WorkspaceName)
$AzureAutomationSolution = $SolutionEnabled | where-object Name -eq "AzureAutomation"
if (!$AzureAutomationSolution.Enabled)
{
    write-host "the solution has not been enabled"
}

# Check for the MMA on the machine
try
{

    $mma = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
    Write-Output "Configuring the MMA..."
    $mma.AddCloudWorkspace($WorkspaceId.CustomerId.Guid, $WorkspaceKey)
    $mma.ReloadConfiguration()
}
catch
{
    # Download the Microsoft monitoring agent
    Write-Output "Downloading and installing the Microsoft Monitoring Agent..."
    $MMASetupUri = "https://go.microsoft.com/fwlink/?LinkId=828603"
    Invoke-RestMethod -Method Get -Uri  $MMASetupUri -OutFile $DestinationPath


    # Install the MMA
    $Command = "/C:setup.exe /qn ADD_OPINSIGHTS_WORKSPACE=1 OPINSIGHTS_WORKSPACE_ID=$WorkspaceID" + " OPINSIGHTS_WORKSPACE_KEY=$WorkspaceKey " + " AcceptEndUserLicenseAgreement=1"
    & $DestinationPath $Command
}

# Sleep until the MMA object has been registered
Write-Output "Waiting for agent registration to complete..."
# Activate the Azure Automation solution in the workspace
Write-Output "Enable AzureAutomation IntelligencePack..."
Get-AzOperationalInsightsIntelligencePack -ResourceGroupName $ResourceGroupName -WorkspaceName $WorkspaceName
Set-AzOperationalInsightsIntelligencePack -ResourceGroupName $ResourceGroupName -WorkspaceName $WorkspaceName -IntelligencePackName "AzureAutomation" -Enabled $true
#get-azoperationalinsightsintelligencepack -ResourceGroupName $ResourceGroupName -WorkspaceName $WorkspaceName
# Timeout = 180 seconds = 3 minutes
$i = 180
do
{
    # Check for the MMA folders
    try
    {
        # Change the directory to the location of the hybrid registration module
        cd "$env:ProgramFiles\Microsoft Monitoring Agent\Agent\AzureAutomation"
        $version = (ls | Sort-Object LastWriteTime -Descending | Select -First 1).Name
        cd "$version\HybridRegistration"

        # Import the module
        Import-Module (Resolve-Path('HybridRegistration.psd1'))

        # Mark the flag as true
        $hybrid = $true
    }
    catch
    {
        $hybrid = $false
    }
    # Sleep for 10 seconds
    Start-Sleep -s 10
    $i--

} until ($hybrid -or ($i -le 0))

if ($i -le 0)
{
    throw "The HybridRegistration module was not found. Please ensure the Microsoft Monitoring Agent was correctly installed."
}

# Register the hybrid runbook worker
Write-Output "Registering the hybrid runbook worker..."

try
{
    Add-HybridRunbookWorker -Name $HybridGroupName -EndPoint $AutomationEndpoint -Token $AutomationPrimaryKey -Verbose
}
catch
{
    throw $_.exception
}