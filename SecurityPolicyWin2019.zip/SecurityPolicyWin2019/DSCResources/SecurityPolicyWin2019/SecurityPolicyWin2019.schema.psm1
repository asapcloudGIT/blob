Configuration SecurityPolicyWin2019
{

    import-dscresource -modulename PSDesiredStateConfiguration
    Import-DscResource -ModuleName SecurityPolicyDsc -ModuleVersion 2.8.0.0

    #Account Policies
    AccountPolicy ASAPCLOUDAccountPolicies
    {
        Name                                        = "ASAPCLOUD Account Policies"
        Minimum_Password_Length                     = 14
        Maximum_Password_Age                        = 70
        Minimum_Password_Age                        = 1
        Enforce_password_history                    = 24
        Password_must_meet_complexity_requirements  = 'Enabled'
        Store_passwords_using_reversible_encryption = 'Disabled'
    }
    ####

    ##SecurityOption(s)
    SecurityOption guestaccountstatus
    {
        Name                          = "GuestAccountStatus"
        Accounts_Guest_account_status = 'Disabled'
    }
    ##

    ##User Rights Assignment
    UserRightsAssignment PerformVolumeMaintenanceTask
    {
        Ensure   = 'Present'
        Identity = 'Administrators'
        Policy   = 'Perform_volume_maintenance_tasks'
    }

    UserRightsAssignment LoadUnloadDeviceDrivers
    {
        Ensure   = 'Present'
        Identity = 'Administrators', 'Print Operators'
        Policy   = 'Load_and_unload_device_drivers'
    }

    UserRightsAssignment IncreaseSchedulingPrio
    {
        Ensure   = 'Present'
        Identity = 'Administrators'
        Policy   = 'Increase_scheduling_priority'
    }

    UserRightsAssignment GenerateSecurityAudits
    {
        Ensure   = 'Present'
        Identity = 'Local Service', 'Network Service', 'IIS APPPOOL\DefaultAppPool'
        Policy   = 'Generate_security_audits'
    }

    UserRightsAssignment ForceShutDownRemoteSys
    {
        Ensure   = 'Present'
        Identity = 'Administrators'
        Policy   = 'Force_shutdown_from_a_remote_system'
    }



    UserRightsAssignment DenylogonRDPSvc
    {
        Ensure   = 'Present'
        Identity = 'Guests'
        Policy   = 'Deny_log_on_through_Remote_Desktop_Services'
    }

    UserRightsAssignment DenylogonLocaly
    {
        Ensure   = 'Present'
        Identity = 'Guests'
        Policy   = 'Deny_log_on_locally'
    }

    UserRightsAssignment DenylogonAsBatch
    {
        Ensure   = 'Present'
        Identity = 'Guests'
        Policy   = 'Deny_log_on_as_a_batch_job'
    }

    UserRightsAssignment CreateGlobalObjects
    {
        Ensure   = 'Present'
        Identity = 'Administrators', 'SERVICE', 'LOCAL SERVICE', 'NETWORK SERVICE'
        Policy   = 'Create_global_objects'
    }

    UserRightsAssignment CreatePageFile
    {
        Ensure   = 'Present'
        Identity = 'Administrators'
        Policy   = 'Create_a_pagefile'
    }

    UserRightsAssignment IncreaseProcessWorkSet
    {
        Ensure   = 'Present'
        Identity = 'Administrators', 'Local Service'
        Policy   = 'Increase_a_process_working_set'
    }

    UserRightsAssignment ChangeTimeZone
    {
        Ensure   = 'Present'
        Identity = 'Administrators', 'Local Service'
        Policy   = 'Change_the_time_zone'
    }

    UserRightsAssignment ChangeSystemTime
    {
        Ensure   = 'Present'
        Identity = 'Administrators', 'Local Service', 'Server Operators'
        Policy   = 'Change_the_system_time'
    }

    UserRightsAssignment ModifyFirmwareEnvVal
    {
        Ensure   = 'Present'
        Identity = 'Administrators'
        Policy   = 'Modify_firmware_environment_values'
    }


    UserRightsAssignment BackupFilesDirectories
    {
        Ensure   = 'Present'
        Identity = 'Administrators', 'Backup Operators', 'Server Operators'
        Policy   = 'Back_up_files_and_directories'
    }

    UserRightsAssignment ByPassTraverseChecking
    {
        Ensure   = 'Present'
        Identity = 'Administrators', 'Authenticated Users', 'Backup Operators', 'Local Service', 'Network Service'
        Policy   = 'Bypass_traverse_checking'
    }

    UserRightsAssignment OwnershipFilesObjects
    {
        Ensure   = 'Present'
        Identity = 'Administrators'
        Policy   = 'Take_ownership_of_files_or_other_objects'
    }

    UserRightsAssignment ManageAuditSecurityLog
    {
        Ensure   = 'Present'
        Identity = 'Administrators'
        Policy   = 'Manage_auditing_and_security_log'
    }

    UserRightsAssignment DenyAccessToThisComputerNetwork
    {
        Ensure   = 'Present'
        Identity = 'Guests'
        Policy   = 'Deny_access_to_this_computer_from_the_network'
    }

    UserRightsAssignment CreateSymbolicLinks
    {
        Ensure   = 'Present'
        Identity = 'Administrators', 'NT VIRTUAL MACHINE\Virtual Machines'
        Policy   = 'Create_symbolic_links'
    }

    UserRightsAssignment AllowLogonRDPSvc
    {
        Ensure   = 'Present'
        Identity = 'Administrators', 'Remote Desktop Users'
        Policy   = 'Allow_log_on_through_Remote_Desktop_Services'
    }

    UserRightsAssignment AllowLogonLocally
    {
        Ensure   = 'Present'
        Identity = 'Administrators'
        Policy   = 'Allow_log_on_locally'
    }

    UserRightsAssignment AccessThisComputerFromNetwork
    {
        Ensure   = 'Present'
        Identity = 'Administrators', 'Authenticated Users'
        Policy   = 'Access_this_computer_from_the_network'
    }

    UserRightsAssignment ShutdownTheSystem
    {
        Ensure   = 'Present'
        Identity = 'Administrators'
        Policy   = 'Shut_down_the_system'
    }

    UserRightsAssignment RestoreFilesDirectories
    {
        Ensure   = 'Present'
        Identity = 'Administrators', 'Backup Operators'
        Policy   = 'Restore_files_and_directories'
    }

    UserRightsAssignment ReplaceProcessLvlToken
    {
        Ensure   = 'Present'
        Identity = 'LOCAL SERVICE', 'NETWORK SERVICE'
        Policy   = 'Replace_a_process_level_token'
    }

    UserRightsAssignment ProfileSystemPerformance
    {
        Ensure   = 'Present'
        Identity = 'Administrators', 'NT SERVICE\WdlServiceHost'
        Policy   = 'Profile_system_performance'
    }

    UserRightsAssignment ProfileSinglePerformance
    {
        Ensure   = 'Present'
        Identity = 'Administrators'
        Policy   = 'Profile_single_process'
    }
}
